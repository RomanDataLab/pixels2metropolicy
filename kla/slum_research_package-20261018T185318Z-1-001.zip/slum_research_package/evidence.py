"""The Phase 10.2 evidence lock, plus the record of superseded findings."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from . import data_loader as dl

__all__ = [
    "get_evidence_claims", "get_claim", "get_claim_statuses",
    "get_superseded_findings", "get_interpretation_rules",
]

#: Normalised buckets over the free-text ``reproduction_status`` column.
#: Ordered prefix rules over the free-text ``reproduction_status`` column.
#: The register stores sentences, not short verdict labels, so the bucket is
#: derived from the leading clause. Order matters: the partial case is tested
#: before the general one.
_STATUS_BUCKETS = (
    ("partially reproduced", "partially_reproduced"),
    ("re-confirmed", "reproduced"),
    ("fully reproduced", "reproduced"),
    ("label counts reproduced", "reproduced"),
    ("reproduced", "reproduced"),
    ("mechanism measured", "measured"),
    ("read directly", "read_from_source"),
    ("reported as frozen", "read_from_source"),
    ("stated constraint", "read_from_source"),
)


def _bucket(raw: str) -> str:
    """Map a free-text reproduction status onto a short bucket."""
    low = (raw or "").lower()
    for needle, bucket in _STATUS_BUCKETS:
        if needle in low:
            return bucket
    return "other"


def _augment(row: Dict[str, str]) -> Dict[str, Any]:
    out = dict(row)
    out["status_bucket"] = _bucket(row.get("reproduction_status", ""))
    out["status_label"] = (row.get("reproduction_status", "").split(":")[0]
                           .split(";")[0].strip())
    return out


def get_evidence_claims(
    search: Optional[str] = None,
    status: Optional[str] = None,
    claim_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Return locked claims from the Phase 10.2 evidence register.

    Args:
        search: case-insensitive substring matched across every field.
        status: a normalised bucket from :func:`get_claim_statuses`, or any
            substring of the raw ``reproduction_status`` text.
        claim_id: return exactly one claim, for example ``"D1-CV"``.

    Returns:
        A list of dicts carrying the register columns unchanged, plus
        ``status_bucket`` and ``status_label``. Each claim keeps its own
        ``denominator``, ``limitation``, ``permitted_wording`` and
        ``prohibited_wording``; a consuming application should render those
        rather than paraphrasing the claim.

    Example:
        >>> claims = get_evidence_claims(status="partially_reproduced")
        >>> [c["claim_id"] for c in claims]
        ['P6-NHA']
    """
    rows = [_augment(r) for r in dl.read_csv("evidence_register")]
    if claim_id:
        rows = [r for r in rows if r.get("claim_id", "").lower() == claim_id.lower()]
    if status:
        low = status.lower()
        rows = [r for r in rows
                if r["status_bucket"] == low
                or low in r.get("reproduction_status", "").lower()]
    if search:
        low = search.lower()
        rows = [r for r in rows if any(low in str(v).lower() for v in r.values())]
    return rows


def get_claim(claim_id: str) -> Dict[str, Any]:
    """Return a single claim by id, or raise ``KeyError``."""
    found = get_evidence_claims(claim_id=claim_id)
    if not found:
        raise KeyError(f"No claim with id {claim_id!r}")
    return found[0]


def get_claim_statuses() -> Dict[str, Any]:
    """Return the status vocabulary actually present in the register."""
    rows = get_evidence_claims()
    buckets: Dict[str, int] = {}
    raw: Dict[str, int] = {}
    for r in rows:
        buckets[r["status_bucket"]] = buckets.get(r["status_bucket"], 0) + 1
        raw[r["status_label"]] = raw.get(r["status_label"], 0) + 1
    return {
        "total_claims": len(rows),
        "buckets": dict(sorted(buckets.items())),
        "raw_labels": dict(sorted(raw.items())),
        "source": dl.REGISTRY["evidence_register"].location,
    }


#: Findings that later work overturned. Each entry points at what replaced it.
_SUPERSEDED = [
    {
        "finding": "Phase 9 H1: a footprint coverage gap in 46 congested communities.",
        "phase": "Phase 9",
        "status": "withdrawn",
        "why_wrong": (
            "The zero value was a count of 100 m density cells whose centres fall "
            "inside the polygon, not a count of buildings."
        ),
        "corrected_by": "09_urban_blindspots/audit_2026-10-11/AUDIT_REPORT.md",
        "corrected_result": (
            "All 626 congested-type communities contain at least one mapped building "
            "under both attribution rules. Re-confirmed in Phase 10.2."
        ),
    },
    {
        "finding": "Phase 10: the 374 versus 367 stage-3 gap is sequential versus independent evaluation.",
        "phase": "Phase 10",
        "status": "wrong",
        "why_wrong": "Sequential evaluation gives 368, not 367.",
        "corrected_by": "10_1_reconciliation/reconciliation_report.md",
        "corrected_result": (
            "Stage 3 is a joint per-cell condition: one cell must satisfy "
            "n_bld >= 15 AND prob_p90 > 0.7 at once. Corrected stage 3 is 438, not 441."
        ),
    },
    {
        "finding": "Phase 10: the detected group shows no attribution error.",
        "phase": "Phase 10",
        "status": "wrong",
        "why_wrong": (
            "It compared the medians of two columns instead of the median of their "
            "per-community difference."
        ),
        "corrected_by": "10_1_reconciliation/reconciliation_report.md",
        "corrected_result": (
            "Median per-community C minus A is 18 for the 74 and 15 for the 552. Both "
            "groups are under-attributed similarly, so attribution error cannot explain "
            "the size difference between them."
        ),
    },
    {
        "finding": "Phase 10.1: the cluster rule is rook adjacency with more than 2 cells.",
        "phase": "Phase 10.1",
        "status": "falsified",
        "why_wrong": (
            "That variant returned 243 against the logged 244, which was a coincidence. "
            "The frozen candidate file shows 103 clusters holding exactly 2 cells."
        ),
        "corrected_by": "10_2_evidence_lock/reproducibility_report.md",
        "corrected_result": (
            "Queen adjacency with a minimum of 2 cells. All 244 frozen clusters sit "
            "inside exactly one queen component, against 241 under rook."
        ),
    },
    {
        "finding": "Phase 10.1: the 300 m NHA filter moves the cluster count away from 244.",
        "phase": "Phase 10.1",
        "status": "wrong_reference_layer",
        "why_wrong": (
            "It used the 177-point Baan Mankong file rather than the 1,588 NHA records "
            "the frozen run used."
        ),
        "corrected_by": "10_2_evidence_lock/reproducibility_report.md",
        "corrected_result": (
            "The filter was applied correctly in the frozen run: the minimum retained "
            "dist_nha_m is 301.229 m. It still cannot be reproduced, because the NHA "
            "coordinates are not preserved."
        ),
    },
]


def get_superseded_findings() -> List[Dict[str, Any]]:
    """Return earlier conclusions that later audits overturned.

    A consuming application should show these as corrected rather than hiding
    them, and should link to ``corrected_by`` wherever the original is cited.
    """
    return [dict(x) for x in _SUPERSEDED]


def get_interpretation_rules() -> Dict[str, Any]:
    """Return the framing and wording rules that govern how claims are shown."""
    from .config import POSITIONING, INTERPRETATION_RULES, PROHIBITED_WORDING
    return {
        "positioning": dict(POSITIONING),
        "rules": list(INTERPRETATION_RULES),
        "prohibited_wording": list(PROHIBITED_WORDING),
    }
