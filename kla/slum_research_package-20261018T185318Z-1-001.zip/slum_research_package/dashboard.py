"""Composed views a web application can render without reassembling the research.

These functions only combine what the other modules return. They introduce no new
numbers and no new claims.
"""
from __future__ import annotations

from typing import Any, Dict, List

from . import data_loader as dl
from . import evidence, metrics, spatial_layers, validation
from .config import POSITIONING, INTERPRETATION_RULES, PROHIBITED_WORDING, get_paths, D1_RUN_ID

__all__ = ["get_project_overview", "get_dashboard_payload", "get_phase_timeline",
           "get_data_health"]


_PHASES = [
    {"phase": "D-1", "title": "Frozen baseline run", "status": "frozen",
     "summary": "1,803,195 footprints, 123,917 density cells, 16 features, district-grouped spatial CV."},
    {"phase": "Phase 5", "title": "Blind image review", "status": "frozen",
     "summary": "40 frames, one reviewer, sealed labels. The primary test did not demonstrate discovery outside the register."},
    {"phase": "Phase 6", "title": "Candidate-generation diagnosis", "status": "frozen",
     "summary": "The gap mask deletes qualifying cells inside registered boundaries by design."},
    {"phase": "Phase 7", "title": "Morphology diagnosis", "status": "authoritative",
     "summary": "Density and position separate; shape descriptors sit near chance and two are source artefacts."},
    {"phase": "Phase 8", "title": "Synthesis and deck", "status": "partially_missing",
     "summary": "Deliverables were built in session and never copied into the repository."},
    {"phase": "Phase 9", "title": "Urban blind spots", "status": "superseded",
     "summary": "The H1 coverage-gap finding was withdrawn by the audit of 2026-10-11."},
    {"phase": "Phase 10", "title": "Corrected attribution", "status": "partially_superseded",
     "summary": "Methods A, B and C reproduce exactly; two of its interpretations were later corrected."},
    {"phase": "Phase 10.1", "title": "Reconciliation", "status": "partially_superseded",
     "summary": "Closed the funnel against the run log; its cluster-rule identification was later falsified."},
    {"phase": "Phase 10.2", "title": "Evidence lock", "status": "authoritative",
     "summary": "20 locked claims, each traced to a file. Settled the queen-adjacency cluster rule."},
    {"phase": "Phase 10.3", "title": "Independent validation design", "status": "pending",
     "summary": "300-unit design, sampling frame and codebook. No review conducted."},
]


def get_phase_timeline() -> List[Dict[str, Any]]:
    """Return the research phases with their authority status."""
    return [dict(p) for p in _PHASES]


def get_project_overview() -> Dict[str, Any]:
    """Return the headline framing, scale and current status of the project.

    This is the call a host application should make first. It carries the
    positioning statement and the interpretation rules that constrain how every
    other payload may be rendered.
    """
    paths = get_paths()
    try:
        val = validation.get_validation_status()
        val_status = val["status"]
        val_headline = val["headline"]
    except Exception as exc:
        val_status, val_headline = "UNKNOWN", f"{type(exc).__name__}: {exc}"
    return {
        "project": "Pixels2MetroPolicy_TH",
        "city": "Bangkok",
        "frozen_run_id": D1_RUN_ID,
        "positioning": dict(POSITIONING),
        "scale": {
            "building_footprints": 1803195,
            "density_cells_100m": 123917,
            "registered_communities": 1993,
            "congested_type_communities": 626,
            "candidate_areas": 244,
            "confirmed_informal_settlements": 0,
        },
        "population_warning": (
            "The 626 congested-type subset and the 1,993 registered communities are "
            "different populations and must never be compared against one another."
        ),
        "validation_status": val_status,
        "validation_headline": val_headline,
        "interpretation_rules": list(INTERPRETATION_RULES),
        "prohibited_wording": list(PROHIBITED_WORDING),
        "paths": paths.describe(),
    }


def get_data_health() -> Dict[str, Any]:
    """Return which declared sources resolve right now, and which do not."""
    sources = dl.list_sources()
    present = [s for s in sources if s["exists"]]
    absent = [s for s in sources if not s["exists"]]
    layers = spatial_layers.get_available_layers()
    return {
        "sources_declared": len(sources),
        "sources_present": len(present),
        "sources_absent": len(absent),
        "absent": [
            {"key": s["key"], "phase": s["phase"], "authority": s["authority"],
             "reason": s["note"] or s["description"]}
            for s in absent
        ],
        "layers_available": [l["name"] for l in layers if l["available"]],
        "layers_unavailable": [
            {"name": l["name"], "reason": l.get("missing_reason", "")}
            for l in layers if not l["available"]
        ],
        "by_authority": {
            a: sum(1 for s in sources if s["authority"] == a)
            for a in sorted({s["authority"] for s in sources})
        },
    }


def get_dashboard_payload() -> Dict[str, Any]:
    """Return one payload with everything a research dashboard needs.

    Heavy spatial geometry is deliberately excluded. Call
    :func:`slum_research_package.get_spatial_layer` for that, with a bounding box.
    """
    return {
        "overview": get_project_overview(),
        "timeline": get_phase_timeline(),
        "metrics": metrics.get_metrics(),
        "evidence": {
            "claims": evidence.get_evidence_claims(),
            "statuses": evidence.get_claim_statuses(),
            "superseded": evidence.get_superseded_findings(),
        },
        "validation": {
            "status": validation.get_validation_status(),
            "design": validation.get_sampling_design(),
            "limitations": validation.get_known_limitations(),
            "missing_inputs": validation.get_missing_inputs(),
        },
        "layers": spatial_layers.get_available_layers(),
        "data_health": get_data_health(),
    }
