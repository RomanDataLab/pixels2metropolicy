"""Put the directory holding the package on sys.path, then share fixtures."""
import sys
from pathlib import Path

import pytest

# tests/ -> slum_research_package/ -> project root, which is the import root.
_PKG_PARENT = Path(__file__).resolve().parents[2]
if str(_PKG_PARENT) not in sys.path:
    sys.path.insert(0, str(_PKG_PARENT))


@pytest.fixture(scope="session")
def sr():
    import slum_research_package
    return slum_research_package


@pytest.fixture(scope="session")
def have_project(sr):
    """Skip data-dependent tests when the project tree is not reachable."""
    try:
        sr.get_paths()
    except sr.ProjectRootNotFound:
        pytest.skip("Project root not reachable in this environment")
    return True
