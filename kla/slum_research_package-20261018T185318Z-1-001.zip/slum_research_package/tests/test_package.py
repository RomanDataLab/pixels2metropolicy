"""Tests for slum_research_package.

Data-dependent tests skip when the project tree is not reachable, so the suite
is honest about what it could and could not check in a given environment.
"""
import os
from pathlib import Path

import pytest


# --------------------------------------------------------------- imports ----

def test_package_imports(sr):
    assert sr.__version__
    for name in ("get_project_overview", "get_evidence_claims", "get_metrics",
                 "get_available_layers", "get_spatial_layer", "get_validation_status"):
        assert callable(getattr(sr, name)), name


def test_positioning_is_not_a_detector(sr):
    text = sr.POSITIONING["framework"].lower()
    assert "not an automated slum detector" in text
    assert sr.POSITIONING["confirmed_settlements"] == 0


def test_prohibited_wording_declared(sr):
    for phrase in ("detected slum", "vulnerability score", "confirmed informal settlement"):
        assert phrase in sr.PROHIBITED_WORDING


# -------------------------------------------------------------- evidence ----

def test_evidence_register_reads(sr, have_project):
    claims = sr.get_evidence_claims()
    assert len(claims) == 20
    required = {"claim_id", "claim", "evidence_source", "reproduction_status",
                "denominator", "result", "interpretation", "limitation",
                "permitted_wording", "prohibited_wording", "next_validation_step"}
    assert required.issubset(set(claims[0]))
    assert all(c["denominator"].strip() for c in claims), "every claim carries a denominator"
    assert all(c["limitation"].strip() for c in claims), "every claim carries a limitation"


def test_evidence_filtering(sr, have_project):
    partial = sr.get_evidence_claims(status="partially_reproduced")
    assert [c["claim_id"] for c in partial] == ["P6-NHA"]
    found = sr.get_evidence_claims(search="NHA")
    assert "P6-NHA" in [c["claim_id"] for c in found]
    assert sr.get_claim("FUNNEL")["claim_id"] == "FUNNEL"
    with pytest.raises(KeyError):
        sr.get_claim("NOT-A-CLAIM")


def test_superseded_findings_point_to_corrections(sr):
    sup = sr.get_superseded_findings()
    assert len(sup) >= 4
    for item in sup:
        assert item["corrected_by"], "a superseded finding must name what replaced it"
        assert item["corrected_result"]
    phases = {s["phase"] for s in sup}
    assert "Phase 9" in phases and "Phase 10.1" in phases


# --------------------------------------------------------------- metrics ----

def test_model_auc_matches_frozen_source(sr, have_project):
    mp = sr.get_model_performance()
    assert mp["value"] == pytest.approx(0.7327, abs=5e-5)
    assert mp["gate"] == 0.80
    assert mp["gate_met"] is False
    assert mp["denominator"]["labelled_buildings"] == 435283
    assert mp["denominator"]["positive"] == 101212
    assert "not slum-detection accuracy" in mp["caveat"]


def test_folds_in_order_and_consistent_with_mean(sr, have_project):
    mp = sr.get_model_performance()
    assert mp["folds"] == [0.607, 0.775, 0.669, 0.798, 0.815]
    assert mp["folds_reproduce_recorded_mean"] is True
    assert sum(mp["folds"]) / len(mp["folds"]) == pytest.approx(mp["value"], abs=2e-3)


def test_raw_auc_is_not_separation(sr, have_project):
    table = sr.get_descriptor_table()
    rows = table["rows"]
    assert len(rows) == 18
    for r in rows:
        assert r["separation"] == pytest.approx(abs(2 * r["auc"] - 1), abs=0.011)
    by_name = {r["feature"]: r for r in rows}
    # The trap: a descriptor whose raw AUC is below 0.5 still has a large
    # separation, because separation discards direction.
    canal = by_name["canal_dist_med"]
    assert canal["auc"] < 0.5 and canal["separation"] > 0.5
    assert canal["direction"] == "lower_in_consistent"
    assert by_name["dens_cell_ring"]["auc"] == pytest.approx(0.845, abs=1e-3)


def test_descriptor_denominators(sr, have_project):
    d = sr.get_descriptor_table()["denominator"]
    assert d["frames_reviewed"] == 40
    assert d["consistent"] == 10
    assert d["inconsistent"] == 20


def test_separation_mismatch_is_detected(sr):
    """A changed source table must raise rather than be plotted silently."""
    from slum_research_package import metrics
    with pytest.raises(metrics.SeparationMismatch):
        bad = [{"feature": "x", "auc_con_vs_inc": "0.9", "separation": "0.1"}]
        real_read = metrics.dl.read_csv
        metrics.dl.read_csv = lambda key: bad if key == "descriptor_table" else real_read(key)
        try:
            metrics.get_descriptor_table(check=True)
        finally:
            metrics.dl.read_csv = real_read


def test_funnel_denominator_is_always_626(sr, have_project):
    f = sr.get_funnel()
    assert f["denominator"]["congested_communities"] == 626
    assert f["denominator"]["all_registered_communities"] == 1993
    stages = {s["stage"]: s for s in f["stages"]}
    assert (stages["1"]["method_a_centroid"], stages["1"]["method_c_intersect"]) == (580, 626)
    assert (stages["2"]["method_a_centroid"], stages["2"]["method_c_intersect"]) == (566, 623)
    assert (stages["3"]["method_a_centroid"], stages["3"]["method_c_intersect"]) == (367, 438)
    assert all(s["denominator"] == 626 for s in f["stages"])
    assert "counting rule" in f["caveat"]


def test_candidate_chain_and_cluster_rule(sr, have_project):
    c = sr.get_candidate_chain()
    values = {s["step"]: s["value"] for s in c["steps"]}
    assert values["cells meeting the joint rule"] == 4361
    assert values["of those, outside every registered boundary"] == 2918
    assert values["candidate clusters"] == 244
    assert c["cluster_rule"]["adjacency"].startswith("queen")
    assert c["cluster_rule"]["min_cells"] == 2
    assert c["logged_versus_reconstructed"]["qualifying_cells_logged"] == 4372


def test_blind_review_carries_sample_size(sr, have_project):
    b = sr.get_blind_review()
    assert b["denominator"]["frames_total"] == 40
    assert b["denominator"]["reviewers"] == 1
    assert b["primary_endpoint"]["candidates_pct_consistent"] == 8.3
    assert b["primary_endpoint"]["background_pct_consistent"] == 12.5
    assert b["communities_touching_a_candidate"]["count"] == 74
    assert b["communities_touching_a_candidate"]["denominator"] == 626
    assert "not a detection rate" in b["communities_touching_a_candidate"]["caveat"]


def test_get_metrics_returns_all_blocks(sr, have_project):
    m = sr.get_metrics()
    for key in ("model_performance", "descriptor_separation", "community_funnel",
                "blind_review", "candidate_chain", "attribution_sensitivity"):
        assert key in m
        assert "error" not in m[key], f"{key}: {m[key].get('error')}"


# ------------------------------------------------------------ validation ----

def test_validation_is_pending(sr, have_project):
    v = sr.get_validation_status()
    assert v["status"] == "PENDING"
    assert v["gate_open"] is False
    assert "has not been conducted" in v["headline"]
    assert set(v["blocking_gates_unmet"]) >= {"G1", "G2"}
    joined = " ".join(v["what_does_not_exist"]).lower()
    assert "confirmed informal-settlement location" in joined


def test_no_validation_outcome_fields_exist(sr, have_project):
    v = sr.get_validation_status()
    forbidden = {"accuracy", "precision", "recall", "outcome", "result_pct", "kappa_value"}
    assert not forbidden & set(v)


def test_sampling_design_matches_frame(sr, have_project):
    d = sr.get_sampling_design()
    assert d["units_drawn"] == 300
    assert d["by_stratum"]["flagged_candidate"] == 120
    assert d["by_stratum"]["unflagged_dense_outside"] == 120
    assert d["by_stratum"]["registered_congested"] == 60
    assert d["matching_shortfalls"] in ([], None)
    assert d["status"] == "PENDING"


def test_known_limitations_present(sr):
    ids = {x["id"] for x in sr.get_known_limitations()}
    assert {"no_ground_truth", "nha_coordinates_missing", "generator_not_reproducible"} <= ids


# --------------------------------------------------------------- spatial ----

def test_layer_metadata_is_complete(sr, have_project):
    for layer in sr.get_available_layers():
        for key in ("name", "geometry_type", "serving_policy", "available",
                    "caveat", "fields", "study_area", "authority"):
            assert key in layer, (layer["name"], key)


def test_candidate_layer_serves_244(sr, have_project):
    fc = sr.get_spatial_layer("candidate_areas")
    assert fc["type"] == "FeatureCollection"
    assert fc["metadata"]["features_total"] == 244
    props = fc["features"][0]["properties"]
    assert {"n_cells", "n_bld", "prob_mean", "dist_nha_m"} <= set(props)
    assert "confirmed informal settlement" in fc["metadata"]["caveat"].lower()


def test_bbox_and_limit_reduce_results(sr, have_project):
    full = sr.get_spatial_layer("candidate_areas")
    small = sr.get_spatial_layer("candidate_areas", bbox=[100.4, 13.6, 100.6, 13.8])
    assert small["metadata"]["features_matched"] <= full["metadata"]["features_total"]
    capped = sr.get_spatial_layer("candidate_areas", limit=5)
    assert capped["metadata"]["features_returned"] == 5
    page2 = sr.get_spatial_layer("candidate_areas", limit=5, offset=5)
    first_ids = [f["properties"]["n_cells"] for f in capped["features"]]
    second_ids = [f["properties"]["n_cells"] for f in page2["features"]]
    assert first_ids != second_ids or len(set(first_ids)) == 1


def test_large_layers_are_guarded(sr, have_project):
    with pytest.raises(sr.LayerTooLarge):
        sr.get_spatial_layer("density_cells")          # bounded, needs bbox or limit
    with pytest.raises(sr.LayerTooLarge):
        sr.get_spatial_layer("building_footprints", limit=5)   # file-only, never served
    meta = sr.get_layer_metadata("building_footprints")
    assert meta["serving_policy"] == "file_only"
    assert meta["file_path"].endswith(".zip")


def test_density_bbox_query_works(sr, have_project):
    fc = sr.get_spatial_layer("density_cells", bbox=[100.50, 13.73, 100.52, 13.75])
    assert fc["metadata"]["features_matched"] > 0
    assert fc["metadata"]["features_total"] == 123917
    assert {"n_bld", "prob_p90"} <= set(fc["features"][0]["properties"])


# --------------------------------------------------------- missing inputs ----

def test_missing_layer_is_reported_not_substituted(sr, have_project):
    meta = sr.get_layer_metadata("nha_points")
    assert meta["available"] is False
    assert "not preserved" in meta["missing_reason"].lower() or "coordinates" in meta["missing_reason"].lower()
    with pytest.raises(sr.LayerNotAvailable):
        sr.get_spatial_layer("nha_points")


def test_missing_sources_raise_clearly(sr, have_project):
    from slum_research_package import data_loader as dl
    for key in ("nha_point_coordinates", "candidate_generator_source", "phase8_deck"):
        assert dl.source_exists(key) is False
        with pytest.raises(dl.MissingSource):
            dl.resolve(key)
    keys = {m["key"] for m in sr.get_missing_inputs()}
    assert {"nha_point_coordinates", "candidate_generator_source"} <= keys


def test_unknown_source_key_raises(sr):
    from slum_research_package import data_loader as dl
    with pytest.raises(KeyError):
        dl.resolve("no_such_source")


# ------------------------------------------------------------- read-only ----

def test_package_declares_no_write_calls():
    """Static check: no module opens a project file for writing."""
    pkg = Path(__file__).resolve().parents[1]
    offenders = []
    for path in sorted(pkg.glob("*.py")):
        text = path.read_text(encoding="utf-8")
        for bad in ('"w"', "'w'", '"a"', "'a'", ".write_text(", ".write_bytes(",
                    "os.remove(", "shutil.", "os.rename("):
            if bad in text:
                offenders.append((path.name, bad))
    assert not offenders, f"write-capable calls found: {offenders}"


def test_reads_do_not_change_source_mtimes(sr, have_project):
    from slum_research_package import data_loader as dl
    watched = ["evidence_register", "corrected_funnel", "descriptor_table"]
    before = {k: dl.resolve(k).stat().st_mtime_ns for k in watched}
    sr.get_dashboard_payload()
    after = {k: dl.resolve(k).stat().st_mtime_ns for k in watched}
    assert before == after


def test_path_guard_rejects_outside_project(sr, have_project):
    from slum_research_package.config import assert_within_project
    with pytest.raises(PermissionError):
        assert_within_project(Path("/etc/passwd"))


# ------------------------------------------------------------------- api ----

def test_route_summary_is_documented(sr):
    from slum_research_package import api
    assert len(api.ROUTE_SUMMARY) >= 10
    assert all(r["method"] == "GET" for r in api.ROUTE_SUMMARY), "the router is read-only"


def test_router_builds_or_reports_missing_fastapi(sr):
    from slum_research_package import api
    try:
        import fastapi  # noqa: F401
    except ImportError:
        with pytest.raises(api.FastAPINotInstalled):
            api.create_router()
        pytest.skip("FastAPI not installed; checked the error path instead")
    router = api.create_router(prefix="/research")
    paths = {r.path for r in router.routes}
    assert "/research/overview" in paths
    assert "/research/validation" in paths


# ------------------------------------------------------------- dashboard ----

def test_overview_states_pending_and_zero_confirmed(sr, have_project):
    o = sr.get_project_overview()
    assert o["validation_status"] == "PENDING"
    assert o["scale"]["confirmed_informal_settlements"] == 0
    assert o["scale"]["candidate_areas"] == 244
    assert o["scale"]["congested_type_communities"] == 626
    assert any("different populations" in r for r in [o["population_warning"]])


def test_data_health_counts_absent_sources(sr, have_project):
    h = sr.get_data_health()
    assert h["sources_present"] + h["sources_absent"] == h["sources_declared"]
    assert h["sources_absent"] >= 3
    assert "nha_points" in [x["name"] for x in h["layers_unavailable"]]
