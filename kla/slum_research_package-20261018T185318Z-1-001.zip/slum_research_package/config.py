"""Project location, constants and the research guard rails.

Nothing in this package writes to the project. Every path resolved here is opened
read-only, and :func:`assert_within_project` is used to reject paths outside the
configured root.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

__all__ = [
    "ProjectRootNotFound", "Paths", "get_paths", "find_project_root",
    "POSITIONING", "INTERPRETATION_RULES", "PROHIBITED_WORDING",
    "D1_RUN_ID", "D1_ZIP", "MAX_INLINE_FEATURES", "MAX_INLINE_BYTES",
    "assert_within_project",
]


class ProjectRootNotFound(RuntimeError):
    """Raised when the Pixels2MetroPolicy_TH project root cannot be located."""


#: Identifier of the frozen baseline run. Every frozen artefact belongs to it.
D1_RUN_ID = "d1_20260926T145135Z"
D1_ZIP = "d1_results_20260926T145135Z.zip"

#: Hard ceilings used by the spatial layer module so an API response cannot
#: accidentally serialise a million footprints.
MAX_INLINE_FEATURES = 5000
MAX_INLINE_BYTES = 8 * 1024 * 1024

#: Candidate locations for the project root, tried in order. The environment
#: variable always wins so a host application can pin the location explicitly.
_ROOT_CANDIDATES = (
    "/content/drive/MyDrive/A_Projects/Pixels2MetroPolicy_TH",
    "G:/My Drive/A_Projects/Pixels2MetroPolicy_TH",
    "G:\\My Drive\\A_Projects\\Pixels2MetroPolicy_TH",
    "~/Google Drive/My Drive/A_Projects/Pixels2MetroPolicy_TH",
    "~/My Drive/A_Projects/Pixels2MetroPolicy_TH",
)

#: The frozen archive lives beside A_Projects, not inside the project root.
_SAFE_RUN_DIRNAME = "P2MP_safe_run"


POSITIONING = {
    "framework": (
        "An evidence-assembly and spatial-triage framework, not an automated "
        "slum detector."
    ),
    "division_of_labour": (
        "AI helps identify WHERE to investigate. Evidence and people determine "
        "WHAT is happening and WHAT should be done."
    ),
    "confirmed_settlements": 0,
}

#: Rules a consuming application must not contradict when rendering this data.
INTERPRETATION_RULES = [
    "An area outside the register is not automatically informal, illegal, poor "
    "or underserved.",
    "A missing record means unknown, never absence of need.",
    "Imagery alone cannot establish tenure, poverty, legality, household status, "
    "community governance or relocation history.",
    "The frozen D-1 mean spatial cross-validation AUC of 0.7327 measures agreement "
    "with registration-derived labels, not slum-detection accuracy.",
    "Independent validation remains pending. Phase 10.3 is a validation design, "
    "not completed validation.",
    "Recall against the 626 congested-type communities is undefined, because the "
    "candidate generator removes registered-community interiors by construction.",
    "Raw AUC and the transformed separation score are different quantities. "
    "separation equals abs(2 * AUC - 1) and discards direction.",
    "The 626 congested-type subset and the 1,993 registered communities are "
    "different populations and must never be compared against one another.",
]

#: Phrases the research record forbids. Exposed so a host application can lint
#: its own copy rather than rediscovering the rules.
PROHIBITED_WORDING = [
    "detected slum", "slum probability", "AI-detected informal settlement",
    "confirmed informal settlement", "vulnerability score", "priority score",
    "detection rate", "recall against the register",
]


@dataclass(frozen=True)
class Paths:
    """Resolved locations the loader reads from."""

    root: Path
    safe_run: Optional[Path] = None

    @property
    def d1_zip(self) -> Optional[Path]:
        if self.safe_run is None:
            return None
        candidate = self.safe_run / D1_ZIP
        return candidate if candidate.exists() else None

    @property
    def sea_raw(self) -> Optional[Path]:
        if self.safe_run is None:
            return None
        candidate = self.safe_run / "SEA_prototype_20260928" / "raw"
        return candidate if candidate.is_dir() else None

    def describe(self) -> dict:
        return {
            "root": str(self.root),
            "root_exists": self.root.is_dir(),
            "safe_run": str(self.safe_run) if self.safe_run else None,
            "safe_run_exists": bool(self.safe_run and self.safe_run.is_dir()),
            "d1_zip": str(self.d1_zip) if self.d1_zip else None,
            "sea_raw": str(self.sea_raw) if self.sea_raw else None,
        }


def find_project_root(explicit: Optional[str] = None) -> Path:
    """Return the project root.

    Resolution order: the ``explicit`` argument, then the ``P2MP_ROOT``
    environment variable, then a short list of known locations for Colab and
    Windows Google Drive.

    Raises:
        ProjectRootNotFound: if no candidate directory exists. The package never
            creates a stand-in project tree.
    """
    tried: List[str] = []
    for value in (explicit, os.environ.get("P2MP_ROOT")):
        if value:
            path = Path(os.path.expanduser(value))
            tried.append(str(path))
            if path.is_dir():
                return path
    for value in _ROOT_CANDIDATES:
        path = Path(os.path.expanduser(value))
        tried.append(str(path))
        if path.is_dir():
            return path
    raise ProjectRootNotFound(
        "Could not locate the Pixels2MetroPolicy_TH project root. Set the "
        "P2MP_ROOT environment variable to the project directory. Tried: "
        + "; ".join(tried)
    )


def _find_safe_run(root: Path) -> Optional[Path]:
    """Locate the frozen archive directory, which sits beside ``A_Projects``."""
    env = os.environ.get("P2MP_SAFE_RUN")
    if env:
        candidate = Path(os.path.expanduser(env))
        return candidate if candidate.is_dir() else None
    for parent in (root.parent.parent, root.parent, root):
        candidate = parent / _SAFE_RUN_DIRNAME
        if candidate.is_dir():
            return candidate
    return None


_PATHS: Optional[Paths] = None


def get_paths(explicit_root: Optional[str] = None, refresh: bool = False) -> Paths:
    """Return cached :class:`Paths`, resolving the project root on first use."""
    global _PATHS
    if _PATHS is None or refresh or explicit_root:
        root = find_project_root(explicit_root)
        _PATHS = Paths(root=root, safe_run=_find_safe_run(root))
    return _PATHS


def assert_within_project(path: Path) -> Path:
    """Guard: refuse to touch anything outside the resolved project tree."""
    paths = get_paths()
    resolved = Path(path).resolve()
    allowed = [paths.root.resolve()]
    if paths.safe_run:
        allowed.append(paths.safe_run.resolve())
    for base in allowed:
        try:
            resolved.relative_to(base)
            return resolved
        except ValueError:
            continue
    raise PermissionError(f"Path is outside the project tree: {resolved}")
