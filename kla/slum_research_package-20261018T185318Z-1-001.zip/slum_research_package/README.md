# slum_research_package

Research data and methods from Pixels2MetroPolicy_TH, packaged for a web application.

> An evidence-assembly and spatial-triage framework, not an automated slum detector.
>
> AI helps identify WHERE to investigate. Evidence and people determine WHAT is
> happening and WHAT should be done.

The package is read-only. It opens the preserved artefacts, attaches provenance,
denominators and limitations, and hands them to a host application. It does not rerun
the pipeline, retrain anything, or generate substitutes for missing inputs.

## Install

No build step. Put the project root on the import path, or copy the package folder
into your application and import it normally.

```python
import sys
sys.path.insert(0, r"G:\My Drive\A_Projects\Pixels2MetroPolicy_TH")
import slum_research_package as sr
```

The project root is found automatically on Colab and on Windows Google Drive. Pin it
explicitly when that fails:

```python
import os
os.environ["P2MP_ROOT"] = r"G:\My Drive\A_Projects\Pixels2MetroPolicy_TH"
os.environ["P2MP_SAFE_RUN"] = r"G:\My Drive\P2MP_safe_run"   # optional
```

If the root cannot be found, `ProjectRootNotFound` is raised. The package never
creates a stand-in project tree.

## Requirements

The core needs the Python standard library only, on Python 3.9 or newer. FastAPI is
optional and used only by `api.create_router()`. See `requirements.txt`.

## Public functions

| Function | Returns |
|---|---|
| `get_project_overview()` | framing, scale, validation status, interpretation rules |
| `get_phase_timeline()` | the ten phases with authority status |
| `get_evidence_claims(search=None, status=None, claim_id=None)` | locked claims with denominator, limitation and wording rules |
| `get_claim(claim_id)` | one claim |
| `get_claim_statuses()` | status vocabulary actually present, with counts |
| `get_superseded_findings()` | overturned findings, each pointing at its correction |
| `get_metrics()` | all metric blocks |
| `get_model_performance()` | frozen spatial CV result and the gate |
| `get_descriptor_table()` | 18 descriptors, raw AUC and separation kept apart |
| `get_funnel()` | the corrected community funnel |
| `get_blind_review()` | Phase 5 endpoints with sample sizes |
| `get_candidate_chain()` | cells to candidates, with the cluster rule |
| `get_attribution_sensitivity()` | how far counts move with the boundary rule |
| `get_available_layers()` | layer metadata and availability |
| `get_layer_metadata(name)` | CRS, geometry, fields, serving policy, provenance |
| `get_spatial_layer(name, bbox=None, limit=None, offset=0)` | GeoJSON FeatureCollection |
| `get_validation_status()` | pending status and the gates |
| `get_sampling_design()` | the Phase 10.3 design and power table |
| `get_known_limitations()` | limitations that constrain downstream claims |
| `get_missing_inputs()` | declared artefacts that are absent |
| `get_data_health()` | which sources and layers resolve right now |
| `get_dashboard_payload()` | everything above except heavy geometry |

## Worked example

```python
import slum_research_package as sr

overview = sr.get_project_overview()
overview["validation_status"]                  # 'PENDING'
overview["scale"]["confirmed_informal_settlements"]   # 0

# Claims, filtered
[c["claim_id"] for c in sr.get_evidence_claims(status="partially_reproduced")]
# ['P6-NHA']

# Metrics keep their denominators and caveats
m = sr.get_model_performance()
m["value"], m["gate"], m["gate_met"]           # 0.7327, 0.8, False
m["folds"]                                     # [0.607, 0.775, 0.669, 0.798, 0.815]
m["caveat"]                                    # agreement with a register label

# Raw AUC and separation are different quantities
rows = {r["feature"]: r for r in sr.get_descriptor_table()["rows"]}
rows["canal_dist_med"]["auc"]                  # 0.2   (below 0.5: inverse)
rows["canal_dist_med"]["separation"]           # 0.6   (direction discarded)

# Spatial layers
sr.get_spatial_layer("candidate_areas", limit=10)
sr.get_spatial_layer("density_cells", bbox=[100.50, 13.73, 100.52, 13.75])
```

## Spatial layers and size policy

| Layer | Features | Policy |
|---|---|---|
| `candidate_areas` | 244 polygons | `inline`, served whole |
| `registered_communities` | 1,993 polygons | `bounded`, needs bbox or limit |
| `density_cells` | 123,917 points | `bounded`, needs bbox or limit |
| `districts` | 180 polygons | `bounded` |
| `canals` | lines | `bounded` |
| `building_footprints` | 1,803,195 | `file_only`, never serialised |
| `nha_points` | 1,588 | missing, coordinates not preserved |

`bounded` layers raise `LayerTooLarge` without a bbox or limit. `building_footprints`
always raises `LayerTooLarge`; use `get_layer_metadata("building_footprints")["file_path"]`
and process it server side. Every response is capped at `MAX_INLINE_FEATURES` (5,000)
and reports `features_matched`, `features_returned` and `truncated`.

Coordinates are EPSG:4326. The frozen candidate file declares
`urn:ogc:def:crs:OGC:1.3:CRS84`, which is reported as `crs_declared_in_file`.

## FastAPI

```python
from fastapi import FastAPI
from slum_research_package.api import create_router

app = FastAPI()
app.include_router(create_router(prefix="/research"))
```

The router is read-only: every route is a GET. `api.ROUTE_SUMMARY` documents the
surface so an application on another framework can mirror it. Calling
`create_router()` without FastAPI installed raises `FastAPINotInstalled` rather than
failing at import time.

Routes: `/overview`, `/timeline`, `/claims`, `/claims/statuses`, `/claims/superseded`,
`/metrics`, `/metrics/{name}`, `/layers`, `/layers/{name}`, `/validation`,
`/validation/design`, `/sources`, `/health`.

## What the host application must not do

These rules come from the Phase 10.2 evidence lock and are returned by
`get_interpretation_rules()` so they can be rendered beside the data:

- Do not call a candidate area an informal settlement. There are 244 potential areas
  requiring further investigation and zero confirmed informal settlements.
- Do not report a detection rate, recall or accuracy against the register. The
  generator removes registered-community interiors by construction, so recall against
  the 626 is undefined rather than low. The 74 communities touching a candidate are not
  74 detections.
- Do not present AUC 0.7327 as slum-detection accuracy. It measures agreement with a
  registration-derived label.
- Do not plot `separation` from a zero baseline. The no-separation point for raw AUC is
  0.5, and `separation` equals `abs(2 * AUC - 1)`, which hides direction.
- Do not mix the 626 congested-type subset with the 1,993 registered communities.
- Do not infer tenure, poverty, legality, household status, community governance or
  relocation history from imagery or morphology.
- Do not describe validation as complete. `get_validation_status()["status"]` is
  `PENDING`.

## Known gaps

| Missing | Consequence |
|---|---|
| NHA point coordinates (1,588) | The 300 m candidate filter cannot be reproduced or audited; 114 excluded clusters are unverifiable. |
| The six original pipeline scripts | Candidate generation cannot be rerun from preserved project code. |
| Phase 8 deck | Built in session, never copied into the repository. |

`get_data_health()` reports these at runtime rather than failing.

## Tests

```bash
python -m pytest slum_research_package/tests -q
```

Data-dependent tests skip when the project tree is unreachable, so the suite reports
honestly in environments without Drive.
