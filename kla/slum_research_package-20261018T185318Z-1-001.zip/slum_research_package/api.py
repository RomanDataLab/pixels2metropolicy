"""Optional FastAPI router.

FastAPI is not a dependency of this package. Importing this module without it
installed is fine; :func:`create_router` raises a clear error instead.

Mounting in a host application::

    from fastapi import FastAPI
    from slum_research_package.api import create_router

    app = FastAPI()
    app.include_router(create_router(prefix="/research"))

The router is read-only. It declares no POST, PUT, PATCH or DELETE route.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from . import dashboard, evidence, metrics, spatial_layers, validation
from . import data_loader as dl

__all__ = ["create_router", "FastAPINotInstalled", "ROUTE_SUMMARY"]


class FastAPINotInstalled(RuntimeError):
    """Raised when create_router is called without FastAPI available."""


#: Documented so a host application on another framework can mirror the surface.
ROUTE_SUMMARY = [
    {"method": "GET", "path": "/overview", "returns": "project framing, scale, validation status"},
    {"method": "GET", "path": "/timeline", "returns": "research phases with authority status"},
    {"method": "GET", "path": "/claims", "query": "search, status, claim_id", "returns": "locked evidence claims"},
    {"method": "GET", "path": "/claims/statuses", "returns": "status vocabulary and counts"},
    {"method": "GET", "path": "/claims/superseded", "returns": "overturned findings and their corrections"},
    {"method": "GET", "path": "/metrics", "returns": "all metric blocks with denominators"},
    {"method": "GET", "path": "/metrics/{name}", "returns": "one metric block"},
    {"method": "GET", "path": "/layers", "returns": "layer metadata and availability"},
    {"method": "GET", "path": "/layers/{name}", "query": "bbox, limit, offset", "returns": "GeoJSON FeatureCollection"},
    {"method": "GET", "path": "/validation", "returns": "pending validation status and gates"},
    {"method": "GET", "path": "/validation/design", "returns": "sampling design and power table"},
    {"method": "GET", "path": "/sources", "query": "authority, phase", "returns": "declared sources with exists flag"},
    {"method": "GET", "path": "/health", "returns": "which sources and layers resolve right now"},
]

_METRIC_FNS = {
    "model_performance": metrics.get_model_performance,
    "descriptor_separation": metrics.get_descriptor_table,
    "community_funnel": metrics.get_funnel,
    "blind_review": metrics.get_blind_review,
    "candidate_chain": metrics.get_candidate_chain,
    "attribution_sensitivity": metrics.get_attribution_sensitivity,
}


def create_router(prefix: str = "/research", tags: Optional[List[str]] = None):
    """Build and return a read-only ``APIRouter``.",

    Args:
        prefix: path prefix for every route.
        tags: OpenAPI tags; defaults to ``["slum-research"]``.

    Raises:
        FastAPINotInstalled: when FastAPI is not importable.
    """
    try:
        from fastapi import APIRouter, HTTPException, Query
    except ImportError as exc:
        raise FastAPINotInstalled(
            "FastAPI is not installed. Install it with: pip install fastapi, or use "
            "the plain Python functions in slum_research_package instead."
        ) from exc

    router = APIRouter(prefix=prefix, tags=tags or ["slum-research"])

    @router.get("/overview")
    def overview() -> Dict[str, Any]:
        return dashboard.get_project_overview()

    @router.get("/timeline")
    def timeline() -> List[Dict[str, Any]]:
        return dashboard.get_phase_timeline()

    @router.get("/claims")
    def claims(search: Optional[str] = None, status: Optional[str] = None,
               claim_id: Optional[str] = None) -> List[Dict[str, Any]]:
        return evidence.get_evidence_claims(search=search, status=status, claim_id=claim_id)

    @router.get("/claims/statuses")
    def claim_statuses() -> Dict[str, Any]:
        return evidence.get_claim_statuses()

    @router.get("/claims/superseded")
    def superseded() -> List[Dict[str, Any]]:
        return evidence.get_superseded_findings()

    @router.get("/metrics")
    def all_metrics() -> Dict[str, Any]:
        return metrics.get_metrics()

    @router.get("/metrics/{name}")
    def one_metric(name: str) -> Dict[str, Any]:
        fn = _METRIC_FNS.get(name)
        if fn is None:
            raise HTTPException(404, f"Unknown metric {name!r}. Options: {sorted(_METRIC_FNS)}")
        return fn()

    @router.get("/layers")
    def layers() -> List[Dict[str, Any]]:
        return spatial_layers.get_available_layers()

    @router.get("/layers/{name}")
    def layer(
        name: str,
        bbox: Optional[str] = Query(None, description="min_lon,min_lat,max_lon,max_lat"),
        limit: Optional[int] = Query(None, ge=1),
        offset: int = Query(0, ge=0),
    ) -> Dict[str, Any]:
        box = None
        if bbox:
            try:
                box = [float(v) for v in bbox.split(",")]
            except ValueError:
                raise HTTPException(400, "bbox must be four comma-separated numbers")
            if len(box) != 4:
                raise HTTPException(400, "bbox must be four comma-separated numbers")
        try:
            return spatial_layers.get_spatial_layer(name, bbox=box, limit=limit, offset=offset)
        except KeyError as exc:
            raise HTTPException(404, str(exc))
        except spatial_layers.LayerNotAvailable as exc:
            raise HTTPException(404, str(exc))
        except spatial_layers.LayerTooLarge as exc:
            raise HTTPException(413, str(exc))

    @router.get("/validation")
    def validation_status() -> Dict[str, Any]:
        return validation.get_validation_status()

    @router.get("/validation/design")
    def validation_design() -> Dict[str, Any]:
        return validation.get_sampling_design()

    @router.get("/sources")
    def sources(authority: Optional[str] = None, phase: Optional[str] = None) -> List[Dict[str, Any]]:
        return dl.list_sources(authority=authority, phase=phase)

    @router.get("/health")
    def health() -> Dict[str, Any]:
        return dashboard.get_data_health()

    return router
