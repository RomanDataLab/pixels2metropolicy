"""Read-only access to the research artefacts, with provenance attached.

Every source the package can serve is declared in :data:`REGISTRY`. A source that
is declared but absent is reported as missing; the loader never substitutes a
stand-in file and never writes.

Three storage locations are supported:

``repo``
    a path relative to the project root.
``zip``
    a member of the frozen D-1 archive, read lazily without extracting.
``safe``
    a path relative to the frozen ``P2MP_safe_run`` directory.
"""
from __future__ import annotations

import csv
import io
import json
import zipfile
from dataclasses import dataclass, asdict
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import get_paths, assert_within_project, D1_RUN_ID

__all__ = [
    "SourceRef", "REGISTRY", "resolve", "list_sources", "source_exists",
    "read_text", "read_json", "read_csv", "open_binary", "MissingSource",
]


class MissingSource(FileNotFoundError):
    """Raised when a declared source is not present on disk."""


@dataclass(frozen=True)
class SourceRef:
    """One declared artefact and what may be said about it."""

    key: str
    store: str            # repo | zip | safe
    location: str         # path relative to the store
    kind: str             # csv | json | geojson | parquet | markdown | log
    phase: str
    authority: str        # frozen | authoritative | superseded | pending | derived | missing
    description: str
    note: str = ""

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["exists"] = source_exists(self.key)
        d["bytes"] = _size(self) if d["exists"] else 0
        return d


def _R(key, loc, kind, phase, authority, desc, note=""):
    return SourceRef(key, "repo", loc, kind, phase, authority, desc, note)


def _Z(key, loc, kind, phase, authority, desc, note=""):
    return SourceRef(key, "zip", loc, kind, phase, authority, desc, note)


def _S(key, loc, kind, phase, authority, desc, note=""):
    return SourceRef(key, "safe", loc, kind, phase, authority, desc, note)


_SOURCES: List[SourceRef] = [
    # ---- frozen D-1 baseline ----------------------------------------------
    _Z("classifier_metrics", "04_output/open_stack/bangkok/classifier_metrics.json",
       "json", "D-1", "frozen",
       "Spatial cross-validation metrics and permutation importance for the frozen run.",
       "The only authoritative source for the 0.7327 AUC. It appears nowhere in the repository."),
    _Z("d1_run_summary", "04_output/open_stack/_safe_run/" + D1_RUN_ID + "/run_summary.json",
       "json", "D-1", "frozen", "Run summary with per-fold AUC and label counts."),
    _Z("gap_candidates", "04_output/open_stack/bangkok/gap_candidates.geojson",
       "geojson", "D-1", "frozen",
       "The 244 frozen candidate clusters with n_cells, n_bld, prob_p90_max, prob_mean, dist_nha_m."),
    _Z("density_cells", "04_output/open_stack/bangkok/density100.geojson",
       "geojson", "D-1", "frozen",
       "123,917 density cells on a 100 m lattice, stored as POINTS at cell centres.",
       "Large (about 22 MB). Served by bounding box only."),
    _Z("communities_scored", "04_output/open_stack/bangkok/communities_scored.csv",
       "csv", "D-1", "frozen", "Community-level aggregates for all 1,993 register polygons."),
    _Z("nha_vs_bma", "04_output/open_stack/bangkok/nha_vs_bma.csv",
       "csv", "D-1", "frozen",
       "1,588 NHA records with identifier and status.",
       "Carries NO coordinates. The original NHA point layer is not preserved anywhere."),
    _Z("buildings", "01_data/03_derived_vector/buildings/bangkok_buildings.parquet",
       "parquet", "D-1", "frozen",
       "1,803,195 building footprints.",
       "About 190 MB. Never served through an API response; file access only."),
    _Z("buildings_artery", "01_data/03_derived_vector/buildings/bangkok_buildings_artery.parquet",
       "parquet", "D-1", "frozen",
       "Per-building distance to water, highway, industrial and rail.",
       "About 35 MB. File access only."),
    # ---- sealed phase packages ---------------------------------------------
    _S("phase5_results", "phase5_20260928.zip", "json", "Phase 5", "frozen",
       "Sealed blind-review results: endpoints, strata, expectation bias.",
       "Read as a zip member; see read_json which handles the nested archive."),
    _S("phase6_diagnosis", "phase6_20260928.zip", "json", "Phase 6", "frozen",
       "Gap-finder rule as recorded in the frozen run log, plus reconstruction fidelity."),
    # ---- repository, authoritative ----------------------------------------
    _R("evidence_register", "10_2_evidence_lock/evidence_register.csv", "csv",
       "Phase 10.2", "authoritative",
       "20 locked claims with evidence source, reproduction status, denominator, "
       "limitation, permitted and prohibited wording, and next validation step."),
    _R("corrected_funnel", "10_2_evidence_lock/corrected_funnel.csv", "csv",
       "Phase 10.2", "authoritative",
       "The community funnel under both attribution rules, with the rule evaluated at each stage."),
    _R("funnel_verification", "10_2_evidence_lock/results/funnel_verification.json", "json",
       "Phase 10.2", "authoritative", "Stage counts recomputed from the frozen inputs."),
    _R("chain_verification", "10_2_evidence_lock/results/chain_verification.json", "json",
       "Phase 10.2", "authoritative",
       "Cell chain and cluster-rule verification against the frozen candidate file."),
    _R("descriptor_table", "04_output/social_patterns/bangkok/morphology/morphology_diagnostic_table.csv",
       "csv", "Phase 7", "authoritative",
       "18 morphology descriptors with raw AUC and the transformed separation score.",
       "auc_con_vs_inc is the raw AUC. separation equals abs(2 * AUC - 1) and discards direction."),
    _R("descriptor_provenance", "04_output/social_patterns/bangkok/morphology/morphology_provenance.json",
       "json", "Phase 7", "authoritative",
       "Group sizes behind the descriptor AUCs: 40 frames, 10 consistent, 20 inconsistent."),
    _R("attribution_comparison", "10_corrected_attribution/results/community_attribution_comparison.csv",
       "csv", "Phase 10", "authoritative",
       "Per-community building counts under attribution methods A, B and C."),
    _R("funnel_reconciliation", "10_1_reconciliation/results/funnel_reconciliation.csv", "csv",
       "Phase 10.1", "authoritative", "Funnel stages reconciled against the frozen columns."),
    _R("research_manifest", "private_research_explorer/research_manifest.csv", "csv",
       "All", "derived",
       "254 catalogued artefacts with phase, provenance, status and chapter."),
    # ---- repository, pending ----------------------------------------------
    _R("sampling_frame", "10_3_independent_validation/sampling_frame.csv", "csv",
       "Phase 10.3", "pending",
       "300 sampling units for the designed validation study.",
       "A study design. No review has been conducted and no outcome column exists."),
    _R("review_codebook", "10_3_independent_validation/review_codebook.csv", "csv",
       "Phase 10.3", "pending", "24 observable-only review fields with allowed values."),
    _R("sampling_provenance", "10_3_independent_validation/results/sampling_provenance.json",
       "json", "Phase 10.3", "pending", "Seed, targets, pool sizes and matching shortfalls."),
    _R("unit_construction", "10_3_independent_validation/results/unit_construction.json",
       "json", "Phase 10.3", "pending", "How the flagged and unflagged comparison units were built."),
    # ---- repository, superseded -------------------------------------------
    _R("phase9_superseded_notice", "09_urban_blindspots/SUPERSEDED_SEE_AUDIT.md", "markdown",
       "Phase 9", "superseded",
       "Notice that the Phase 9 H1 coverage-gap finding was withdrawn.",
       "Corrected by the audit of 2026-10-11."),
    _R("phase9_audit_report", "09_urban_blindspots/audit_2026-10-11/AUDIT_REPORT.md", "markdown",
       "Phase 9 audit", "authoritative",
       "The audit that corrected Phase 9 H1."),
    # ---- raw reference layers ----------------------------------------------
    _S("community_boundaries", "SEA_prototype_20260928/raw/community_boundaries.geojson",
       "geojson", "Register", "frozen",
       "1,993 BMA community polygons, 626 of congested type."),
    _S("canals", "SEA_prototype_20260928/raw/canals.geojson", "geojson", "Context", "frozen",
       "Canal network used for context and as a model input."),
    _S("districts", "SEA_prototype_20260928/raw/khet_polygons.geojson", "geojson", "Context", "frozen",
       "Administrative polygons carrying DISTRICT_NAME_E and SUBDISTRICT_NAME_E.",
       "The file is named khet but holds 180 subdistrict polygons across 50 districts."),
    _S("baan_mankong_points", "SEA_prototype_20260928/raw/baan_mankong_points.csv", "csv",
       "Context", "frozen", "177 Baan Mankong points with latitude and longitude.",
       "These are NOT the 1,588 NHA dots used by the frozen candidate filter."),
]

#: Declared sources that are known to be absent from the preserved repository.
_MISSING: List[SourceRef] = [
    SourceRef("nha_point_coordinates", "repo", "", "geojson", "Phase 6", "missing",
              "Coordinates of the 1,588 NHA points used by the 300 m candidate filter.",
              "Absent from both archives. The 114 clusters excluded by that filter cannot be audited."),
    SourceRef("candidate_generator_source", "repo", "", "python", "D-1", "missing",
              "The six original pipeline scripts, including the candidate generator.",
              "Not present in the results archive or the safe-run archive, so candidate "
              "generation cannot be rerun from preserved code."),
    SourceRef("phase8_deck", "repo", "STEP_8_FINAL/Pixel_to_Policy_GeoHackathon_2026.pptx",
              "pptx", "Phase 8", "missing",
              "The Phase 8 presentation deck.",
              "Built in session and never copied into the Drive repository."),
]

REGISTRY: Dict[str, SourceRef] = {s.key: s for s in _SOURCES + _MISSING}


def resolve(key: str) -> Path:
    """Return the filesystem path backing ``key``.

    For a ``zip`` source this is the archive itself, not the member.
    """
    try:
        ref = REGISTRY[key]
    except KeyError:
        raise KeyError(f"Unknown source key: {key!r}. See list_sources().")
    if ref.authority == "missing":
        raise MissingSource(f"{key}: {ref.note or ref.description}")
    paths = get_paths()
    if ref.store == "repo":
        return assert_within_project(paths.root / ref.location)
    if ref.store == "safe":
        if paths.safe_run is None:
            raise MissingSource(f"{key}: the frozen P2MP_safe_run directory was not found.")
        return assert_within_project(paths.safe_run / ref.location)
    if ref.store == "zip":
        if paths.d1_zip is None:
            raise MissingSource(f"{key}: the frozen D-1 archive was not found.")
        return assert_within_project(paths.d1_zip)
    raise ValueError(f"Unknown store {ref.store!r} for {key!r}")


def source_exists(key: str) -> bool:
    """True when the artefact can actually be opened right now."""
    ref = REGISTRY.get(key)
    if ref is None or ref.authority == "missing":
        return False
    try:
        path = resolve(key)
    except (MissingSource, PermissionError):
        return False
    if not path.exists():
        return False
    if ref.store == "zip":
        try:
            with zipfile.ZipFile(path) as zf:
                zf.getinfo(ref.location)
        except KeyError:
            return False
    return True


def _size(ref: SourceRef) -> int:
    try:
        path = resolve(ref.key)
    except (MissingSource, PermissionError):
        return 0
    if ref.store == "zip":
        with zipfile.ZipFile(path) as zf:
            return zf.getinfo(ref.location).file_size
    return path.stat().st_size if path.exists() else 0


def list_sources(authority: Optional[str] = None, phase: Optional[str] = None) -> List[Dict[str, Any]]:
    """Return every declared source, optionally filtered, with an ``exists`` flag."""
    out = []
    for ref in REGISTRY.values():
        if authority and ref.authority != authority:
            continue
        if phase and ref.phase != phase:
            continue
        out.append(ref.to_dict())
    return sorted(out, key=lambda d: (d["phase"], d["key"]))


def _read_bytes(key: str) -> bytes:
    ref = REGISTRY[key]
    path = resolve(key)
    if not path.exists():
        raise MissingSource(f"{key}: not found at {path}")
    if ref.store == "zip":
        with zipfile.ZipFile(path) as zf:
            return zf.read(ref.location)
    if ref.location.endswith(".zip") or path.suffix == ".zip":
        # Sealed phase packages: one archive holding a single results document.
        wanted = {"phase5_results": "phase5_results.json",
                  "phase6_diagnosis": "phase6_diagnosis.json"}.get(key)
        with zipfile.ZipFile(path) as zf:
            member = next(n for n in zf.namelist() if n.endswith(wanted))
            return zf.read(member)
    return path.read_bytes()


@lru_cache(maxsize=64)
def read_text(key: str, encoding: str = "utf-8") -> str:
    """Return a text artefact as a string."""
    return _read_bytes(key).decode(encoding, errors="replace")


@lru_cache(maxsize=64)
def read_json(key: str) -> Any:
    """Return a JSON artefact, including the sealed phase packages."""
    return json.loads(read_text(key))


@lru_cache(maxsize=32)
def _read_csv_cached(key: str) -> tuple:
    text = read_text(key)
    reader = csv.DictReader(io.StringIO(text))
    return tuple(dict(row) for row in reader)


def read_csv(key: str) -> List[Dict[str, str]]:
    """Return a CSV artefact as a list of dicts. Values stay as strings."""
    return [dict(row) for row in _read_csv_cached(key)]


def open_binary(key: str):
    """Return a file-like object for a large artefact such as a parquet layer.

    Intended for server-side processing, never for an API response body.
    """
    ref = REGISTRY[key]
    path = resolve(key)
    if ref.store == "zip":
        return zipfile.ZipFile(path).open(ref.location)
    return open(path, "rb")
