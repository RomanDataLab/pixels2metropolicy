"""Map-ready spatial layers, with the size guards an API needs.

Layers are declared with a serving policy. ``inline`` layers are small enough to
return whole. ``bounded`` layers require a bounding box or an explicit limit.
``file_only`` layers are never serialised into a response; the caller is given a
path and told to process them server side.

Only layers that exist are offered. A declared layer that is absent is reported
as missing, and no substitute is generated.
"""
from __future__ import annotations

import json
from functools import lru_cache
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from . import data_loader as dl
from .config import MAX_INLINE_FEATURES

__all__ = [
    "get_available_layers", "get_layer_metadata", "get_spatial_layer",
    "get_candidate_areas", "LayerTooLarge", "LayerNotAvailable",
]


class LayerTooLarge(ValueError):
    """Raised when a request would serialise more than the layer policy allows."""


class LayerNotAvailable(FileNotFoundError):
    """Raised when a declared layer is not present in the preserved project."""


_LAYERS: Dict[str, Dict[str, Any]] = {
    "candidate_areas": {
        "source": "gap_candidates",
        "title": "Candidate areas requiring further investigation",
        "geometry": "Polygon",
        "feature_count": 244,
        "policy": "inline",
        "unit": "cluster of 100 m density cells",
        "fields": {
            "n_cells": "number of qualifying 100 m cells in the cluster (2 to 46)",
            "n_bld": "mapped buildings inside the cluster",
            "prob_p90_max": "maximum cell-level model-derived signal in the cluster",
            "prob_mean": "mean model-derived signal across the cluster",
            "dist_nha_m": "distance to the nearest NHA point, metres (minimum retained 301.229)",
        },
        "caveat": (
            "These are potential areas requiring further investigation. None is a "
            "confirmed informal settlement, and none has been validated."
        ),
    },
    "registered_communities": {
        "source": "community_boundaries",
        "title": "BMA registered community boundaries",
        "geometry": "Polygon",
        "feature_count": 1993,
        "policy": "bounded",
        "unit": "registered community polygon",
        "fields": {
            "CMT_ID": "community identifier, unique across all 1,993",
            "CMT_TYPE": "community type; the congested class is the 626 subset",
            "CMT_NAME": "community name",
            "DNAME": "district name",
            "HOUSEHOLD": "recorded households",
            "MALE": "recorded male population",
            "FEMALE": "recorded female population",
        },
        "caveat": (
            "The POP field is null for all 1,993 polygons; population must be rebuilt "
            "from MALE plus FEMALE. Registration status is a record, not a measurement "
            "of need."
        ),
    },
    "density_cells": {
        "source": "density_cells",
        "title": "100 m density lattice",
        "geometry": "Point",
        "feature_count": 123917,
        "policy": "bounded",
        "unit": "cell centre on a 100 m lattice",
        "fields": {
            "n_bld": "buildings attributed to the cell",
            "prob_mean": "mean model-derived signal in the cell",
            "prob_p90": "90th percentile model-derived signal in the cell",
        },
        "caveat": (
            "Stored as POINTS at cell centres, never as squares. Any test against a "
            "boundary therefore uses the cell centre, which is the largest measurement "
            "sensitivity in the project."
        ),
    },
    "canals": {
        "source": "canals",
        "title": "Canal network",
        "geometry": "LineString",
        "feature_count": None,
        "policy": "bounded",
        "unit": "canal segment",
        "fields": {},
        "caveat": "A model input as well as context, so not independent evidence.",
    },
    "districts": {
        "source": "districts",
        "title": "Administrative subdistrict polygons",
        "geometry": "Polygon",
        "feature_count": 180,
        "policy": "bounded",
        "unit": "subdistrict polygon",
        "fields": {
            "DISTRICT_NAME_E": "district name, 50 distinct",
            "SUBDISTRICT_NAME_E": "subdistrict name",
        },
        "caveat": "The file is named khet but holds 180 subdistrict polygons.",
    },
    "building_footprints": {
        "source": "buildings",
        "title": "Mapped building footprints",
        "geometry": "Polygon",
        "feature_count": 1803195,
        "policy": "file_only",
        "unit": "building footprint",
        "fields": {"src_id": "source identifier", "height_m": "height where available"},
        "caveat": (
            "About 190 MB of parquet. Never returned through an API response. Process "
            "it server side with the path from get_layer_metadata, or precompute an "
            "aggregate such as the density lattice."
        ),
    },
    "nha_points": {
        "source": "nha_point_coordinates",
        "title": "NHA points used by the 300 m candidate filter",
        "geometry": "Point",
        "feature_count": 1588,
        "policy": "missing",
        "unit": "NHA point",
        "fields": {},
        "caveat": (
            "Coordinates are not preserved. nha_vs_bma.csv keeps identifier and status "
            "only, so the 114 clusters excluded by this filter cannot be audited."
        ),
    },
}


def _geojson_crs(doc: Dict[str, Any]) -> str:
    crs = doc.get("crs")
    if isinstance(crs, dict):
        name = crs.get("properties", {}).get("name")
        if name:
            return str(name)
    return "EPSG:4326 (GeoJSON default; no crs member in file)"


@lru_cache(maxsize=4)
def _load_geojson(source_key: str) -> Tuple[Dict[str, Any], Tuple[Dict[str, Any], ...]]:
    doc = dl.read_json(source_key)
    feats = tuple(doc.get("features", ()))
    head = {k: v for k, v in doc.items() if k != "features"}
    return head, feats


def _coords(geom: Any) -> Iterable[Sequence[float]]:
    if not geom:
        return
    g = geom.get("coordinates")
    stack = [g]
    while stack:
        item = stack.pop()
        if isinstance(item, (list, tuple)):
            if item and isinstance(item[0], (int, float)):
                yield item
            else:
                stack.extend(item)


def _feature_bbox(feat: Dict[str, Any]) -> Optional[Tuple[float, float, float, float]]:
    xs, ys = [], []
    for pt in _coords(feat.get("geometry")):
        xs.append(pt[0])
        ys.append(pt[1])
    if not xs:
        return None
    return (min(xs), min(ys), max(xs), max(ys))


def _intersects(a, b) -> bool:
    return not (a[2] < b[0] or a[0] > b[2] or a[3] < b[1] or a[1] > b[3])


def get_available_layers() -> List[Dict[str, Any]]:
    """Return every declared layer with its metadata and availability."""
    return [get_layer_metadata(name) for name in sorted(_LAYERS)]


def get_layer_metadata(name: str) -> Dict[str, Any]:
    """Return metadata for one layer: CRS, geometry, fields, policy, provenance."""
    if name not in _LAYERS:
        raise KeyError(f"Unknown layer {name!r}. See get_available_layers().")
    spec = _LAYERS[name]
    ref = dl.REGISTRY.get(spec["source"])
    available = spec["policy"] != "missing" and dl.source_exists(spec["source"])
    meta: Dict[str, Any] = {
        "name": name,
        "title": spec["title"],
        "geometry_type": spec["geometry"],
        "feature_count": spec["feature_count"],
        "unit": spec["unit"],
        "fields": dict(spec["fields"]),
        "serving_policy": spec["policy"],
        "available": available,
        "caveat": spec["caveat"],
        "source_key": spec["source"],
        "phase": ref.phase if ref else None,
        "authority": ref.authority if ref else "missing",
        "provenance": ref.description if ref else "",
        "study_area": "Bangkok Metropolitan Administration Comprehensive Plan extent",
        "crs": "EPSG:4326" if spec["geometry"] else None,
    }
    if spec["policy"] == "file_only" and available:
        meta["file_path"] = str(dl.resolve(spec["source"]))
        meta["zip_member"] = ref.location if ref and ref.store == "zip" else None
    if not available:
        if ref:
            meta["missing_reason"] = " ".join(x for x in (ref.description, ref.note) if x)
        else:
            meta["missing_reason"] = "not declared"
    return meta


def get_spatial_layer(
    name: str,
    bbox: Optional[Sequence[float]] = None,
    limit: Optional[int] = None,
    offset: int = 0,
    properties: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    """Return a GeoJSON FeatureCollection for ``name``.

    Args:
        bbox: ``(min_lon, min_lat, max_lon, max_lat)`` in EPSG:4326. Required for
            layers whose policy is ``bounded`` unless ``limit`` is given.
        limit: maximum features to return. Capped at ``MAX_INLINE_FEATURES``.
        offset: features to skip, for pagination.
        properties: restrict returned properties to these keys.

    Raises:
        LayerNotAvailable: the layer is missing from the preserved project.
        LayerTooLarge: the layer is file-only, or a bounded layer was requested
            without a bounding box or limit.

    The returned collection carries a ``metadata`` member with CRS, provenance,
    the caveat for that layer, and the filter actually applied.
    """
    meta = get_layer_metadata(name)
    spec = _LAYERS[name]
    if not meta["available"]:
        raise LayerNotAvailable(f"{name}: {meta.get('missing_reason', 'not available')}")
    if spec["policy"] == "file_only":
        raise LayerTooLarge(
            f"{name} holds {meta['feature_count']:,} features and is not served as "
            f"GeoJSON. Use get_layer_metadata({name!r})['file_path'] and process it "
            "server side."
        )
    if spec["policy"] == "bounded" and bbox is None and limit is None:
        raise LayerTooLarge(
            f"{name} requires a bbox or an explicit limit. It holds "
            f"{meta['feature_count'] or 'many'} features."
        )

    head, feats = _load_geojson(spec["source"])
    total = len(feats)
    selected: List[Dict[str, Any]] = []
    if bbox is not None:
        if len(bbox) != 4:
            raise ValueError("bbox must be (min_lon, min_lat, max_lon, max_lat)")
        box = tuple(float(v) for v in bbox)
        for f in feats:
            fb = _feature_bbox(f)
            if fb and _intersects(fb, box):
                selected.append(f)
    else:
        selected = list(feats)

    matched = len(selected)
    cap = MAX_INLINE_FEATURES if limit is None else min(int(limit), MAX_INLINE_FEATURES)
    window = selected[offset: offset + cap]

    if properties:
        keep = set(properties)
        window = [
            {**f, "properties": {k: v for k, v in (f.get("properties") or {}).items() if k in keep}}
            for f in window
        ]

    return {
        "type": "FeatureCollection",
        "features": window,
        "metadata": {
            **meta,
            "crs_declared_in_file": _geojson_crs(head),
            "features_total": total,
            "features_matched": matched,
            "features_returned": len(window),
            "truncated": matched > offset + len(window),
            "bbox_applied": list(bbox) if bbox else None,
            "offset": offset,
            "limit_applied": cap,
        },
    }


def get_candidate_areas(bbox=None, limit=None, offset=0) -> Dict[str, Any]:
    """Convenience wrapper for the 244 frozen candidate areas."""
    return get_spatial_layer("candidate_areas", bbox=bbox, limit=limit, offset=offset)
