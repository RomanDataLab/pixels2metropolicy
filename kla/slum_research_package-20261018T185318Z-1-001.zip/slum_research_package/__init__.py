"""slum_research_package: research data and methods from Pixels2MetroPolicy_TH.

An evidence-assembly and spatial-triage framework, not an automated slum
detector. AI helps identify WHERE to investigate. Evidence and people determine
WHAT is happening and WHAT should be done.

The package is read-only. It opens the preserved research artefacts, attaches
their provenance, denominators and limitations, and hands them to a host
application. It does not rerun the pipeline, retrain anything, or generate
substitutes for missing inputs.

Quick start::

    import slum_research_package as sr

    sr.get_project_overview()["validation_status"]      # -> 'PENDING'
    sr.get_evidence_claims(status="unresolved")
    sr.get_metrics()["model_performance"]["value"]      # -> 0.7327
    sr.get_available_layers()
    sr.get_spatial_layer("candidate_areas", limit=10)

If the project root is not auto-detected, set ``P2MP_ROOT``::

    import os
    os.environ["P2MP_ROOT"] = r"G:\\My Drive\\A_Projects\\Pixels2MetroPolicy_TH"
"""
from __future__ import annotations

__version__ = "0.1.0"

from .config import (
    POSITIONING,
    INTERPRETATION_RULES,
    PROHIBITED_WORDING,
    ProjectRootNotFound,
    find_project_root,
    get_paths,
)
from .data_loader import (
    MissingSource,
    REGISTRY,
    list_sources,
    read_csv,
    read_json,
    read_text,
    source_exists,
)
from .evidence import (
    get_claim,
    get_claim_statuses,
    get_evidence_claims,
    get_interpretation_rules,
    get_superseded_findings,
)
from .spatial_layers import (
    LayerNotAvailable,
    LayerTooLarge,
    get_available_layers,
    get_candidate_areas,
    get_layer_metadata,
    get_spatial_layer,
)
from .metrics import (
    SeparationMismatch,
    get_attribution_sensitivity,
    get_blind_review,
    get_candidate_chain,
    get_descriptor_table,
    get_funnel,
    get_metrics,
    get_model_performance,
)
from .validation import (
    get_known_limitations,
    get_missing_inputs,
    get_sampling_design,
    get_validation_status,
)
from .dashboard import (
    get_dashboard_payload,
    get_data_health,
    get_phase_timeline,
    get_project_overview,
)

__all__ = [
    "__version__",
    # framing
    "POSITIONING", "INTERPRETATION_RULES", "PROHIBITED_WORDING",
    "get_interpretation_rules",
    # locating the project
    "ProjectRootNotFound", "find_project_root", "get_paths",
    # sources
    "REGISTRY", "list_sources", "source_exists", "read_csv", "read_json",
    "read_text", "MissingSource",
    # evidence
    "get_evidence_claims", "get_claim", "get_claim_statuses",
    "get_superseded_findings",
    # spatial
    "get_available_layers", "get_layer_metadata", "get_spatial_layer",
    "get_candidate_areas", "LayerTooLarge", "LayerNotAvailable",
    # metrics
    "get_metrics", "get_model_performance", "get_descriptor_table", "get_funnel",
    "get_blind_review", "get_candidate_chain", "get_attribution_sensitivity",
    "SeparationMismatch",
    # validation
    "get_validation_status", "get_sampling_design", "get_known_limitations",
    "get_missing_inputs",
    # composed views
    "get_project_overview", "get_dashboard_payload", "get_phase_timeline",
    "get_data_health",
]
