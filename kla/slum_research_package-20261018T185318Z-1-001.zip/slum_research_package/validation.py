"""Validation status, limitations and provenance.

Phase 10.3 produced a study design, a sampling frame, a codebook and a blank
reviewer template. No review has been conducted, so this module reports a pending
status and exposes no outcome field. A host application should render
``status`` prominently wherever candidate areas appear.
"""
from __future__ import annotations

from typing import Any, Dict, List

from . import data_loader as dl

__all__ = ["get_validation_status", "get_sampling_design", "get_known_limitations",
           "get_missing_inputs"]

STATUS_PENDING = "PENDING"


def get_validation_status() -> Dict[str, Any]:
    """Return the current validation state of the project.

    The ``status`` field is ``"PENDING"``. It becomes anything else only when a
    completed review with outcomes exists, which is not the case in the
    preserved project.
    """
    gates = [
        {"gate": "G1", "requirement": "Imagery at 1 m or better with capture dates",
         "met": False, "blocking": True},
        {"gate": "G2", "requirement": "Three or more reviewers independent of the model work",
         "met": False, "blocking": True},
        {"gate": "G3", "requirement": "Codebook frozen after a 10-unit calibration",
         "met": False, "blocking": True, "note": "Codebook written; calibration not run."},
        {"gate": "G4", "requirement": "Blind key isolated from reviewers",
         "met": True, "blocking": True,
         "note": "Verified: the reviewer template carries no stratum, unit id or model score."},
        {"gate": "G5", "requirement": "At least 60 units per comparison group",
         "met": True, "blocking": True,
         "note": "120 flagged, 120 unflagged and 60 registered drawn with zero matching shortfalls."},
        {"gate": "G6", "requirement": "Reviewer agreement, Cohen kappa at least 0.40",
         "met": None, "blocking": True, "note": "Not assessable: no review data exists."},
    ]
    return {
        "status": STATUS_PENDING,
        "headline": (
            "Independent validation has not been conducted. Phase 10.3 is a validation "
            "design, not completed validation."
        ),
        "phase": "Phase 10.3",
        "gate_open": False,
        "blocking_gates_unmet": [g["gate"] for g in gates if g["met"] is False],
        "gates": gates,
        "what_exists": [
            "validation_design.md", "sampling_frame.csv (300 units)",
            "review_codebook.csv (24 observable-only fields)",
            "review_template.csv (blank, 0 answer cells filled)",
            "validation_metrics.md (pre-specified)", "decision_gate.md",
        ],
        "what_does_not_exist": [
            "Any review outcome", "Any agreement statistic",
            "Any confirmed informal-settlement location",
            "Any accuracy, precision or recall against the register",
        ],
        "primary_question": (
            "Do locations flagged by the spatial workflow show independently observable "
            "built-environment characteristics that merit further investigation, "
            "compared with suitable unflagged locations?"
        ),
        "label_rule": (
            "Registration status is deliberately not the validation label, because the "
            "register is the thing under question."
        ),
        "source": "10_3_independent_validation",
        "authority": "pending",
    }


def get_sampling_design() -> Dict[str, Any]:
    """Return the designed sample, read from the Phase 10.3 frame and provenance."""
    prov = dl.read_json("sampling_provenance")
    units = dl.read_json("unit_construction")
    frame = dl.read_csv("sampling_frame")
    by_stratum: Dict[str, int] = {}
    by_context: Dict[str, int] = {}
    for row in frame:
        s = row.get("stratum_flag", "")
        c = row.get("urban_context", "")
        by_stratum[s] = by_stratum.get(s, 0) + 1
        by_context[c] = by_context.get(c, 0) + 1
    return {
        "status": STATUS_PENDING,
        "units_drawn": len(frame),
        "by_stratum": dict(sorted(by_stratum.items())),
        "by_urban_context": dict(sorted(by_context.items())),
        "seed": prov.get("seed"),
        "matching_keys": prov.get("matching_keys"),
        "matching_shortfalls": prov.get("shortfalls"),
        "pool_sizes": prov.get("pool_sizes"),
        "frame_size_m": prov.get("frame_size_m"),
        "comparison_pool_construction": {
            "dense_cells_outside_register": units.get("dense_outside"),
            "of_those_also_meeting_signal_test": units.get("outside_qualifying"),
            "equally_dense_but_unflagged": units.get("outside_dense_unflagged"),
            "unflagged_clusters_built": units.get("unflagged_clusters_ge2"),
            "rule": "Same queen adjacency, minimum 2 cells, as the frozen generator.",
        },
        "power": {
            "test": "two-proportion, alpha 0.05 two-sided",
            "required_per_group": [
                {"baseline": 0.10, "flagged": 0.30, "n_at_80pct": 62},
                {"baseline": 0.10, "flagged": 0.40, "n_at_80pct": 32},
                {"baseline": 0.15, "flagged": 0.30, "n_at_80pct": 121},
                {"baseline": 0.15, "flagged": 0.40, "n_at_80pct": 49},
                {"baseline": 0.20, "flagged": 0.40, "n_at_80pct": 82},
                {"baseline": 0.125, "flagged": 0.30, "n_at_80pct": 85},
            ],
            "note": (
                "Detecting the effect Phase 5 looked for, 12.5 percent against 30 "
                "percent, needs 85 units per group. Phase 5 used 12 and 8."
            ),
        },
        "asymmetry": (
            "The flagged group passed a 300 m NHA distance filter that the comparison "
            "group cannot, because those coordinates are missing. Matching is on size "
            "and urban context only."
        ),
        "source": "10_3_independent_validation/sampling_frame.csv",
        "authority": "pending",
    }


def get_known_limitations() -> List[Dict[str, str]]:
    """Return the limitations that constrain every downstream claim."""
    return [
        {"id": "no_ground_truth",
         "limitation": "There is no independent ground truth anywhere in the project.",
         "consequence": "Every performance figure is measured against the register."},
        {"id": "underpowered_test",
         "limitation": "The one independent test used 12 and 8 frames with a single reviewer.",
         "consequence": "It constrains claims; it does not settle the question."},
        {"id": "lattice_sensitivity",
         "limitation": "The density layer stores cell centres as points, not squares.",
         "consequence": "Outside-register cells move from 2,918 to 1,970 under a footprint rule, a 32.5 percent swing."},
        {"id": "attribution_small_polygons",
         "limitation": "Building attribution shifts more than 20 percent for 99 small communities.",
         "consequence": "Counts for communities under about 1 ha should not drive decisions unverified."},
        {"id": "nha_coordinates_missing",
         "limitation": "The 1,588 NHA point coordinates are not preserved.",
         "consequence": "The 114 clusters excluded by the 300 m filter cannot be audited."},
        {"id": "generator_not_reproducible",
         "limitation": "The six original pipeline scripts are absent from both archives.",
         "consequence": "Candidate generation cannot be rerun from preserved project code."},
        {"id": "label_noise",
         "limitation": "The classifier label set is exactly the centroid-attributed set of 435,283 footprints.",
         "consequence": "Roughly 11,600 buildings that touch a register polygon sit in the unlabelled pool, concentrated in small communities."},
    ]


def get_missing_inputs() -> List[Dict[str, Any]]:
    """Return declared artefacts that are absent, so a host app can show gaps."""
    return [dl.REGISTRY[k].to_dict() for k in dl.REGISTRY
            if dl.REGISTRY[k].authority == "missing"]
